from django.shortcuts import render, redirect
from . models import task
from .forms import taskforms

# Create your views here.
def add(request):
    Task1 = task.objects.all()
    if request.method=='POST':
        name = request.POST.get('task','')
        priority = request.POST.get('priority','')
        date = request.POST.get('date','')
        Task = task(name=name,priority=priority,date=date)
        Task.save()
    return render(request,"home.html",{'task':Task1})

#def detail(request):

   # return render(request,'detail.html',)
def delete(request,taskid):
    Task = task.objects.get(id=taskid)
    if request.method =='POST':
        Task.delete()
        return redirect('/')
    return render(request,'delete.html')

def update(request,id):
    Task = task.objects.get(id=id)
    form = taskforms(request.POST or None,instance=Task)
    if form.is_valid():
        form.save()
        return redirect('/')
    return render(request,"edit.html",{"task":Task,"form":form})

